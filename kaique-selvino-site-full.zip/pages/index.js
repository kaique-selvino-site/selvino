import Head from "next/head";
import KaiqueSelvinoSite from "../components/KaiqueSelvinoSite";

export default function Home() {
  return (
    <>
      <Head>
        <title>Kaique Selvino | Advogado</title>
        <meta name="description" content="Advocacia especializada em Direito Criminal e Civil" />
      </Head>
      <KaiqueSelvinoSite />
    </>
  );
}
