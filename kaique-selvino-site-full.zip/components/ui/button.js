export function Button({ children, className, asChild }) {
  const Tag = asChild ? 'a' : 'button';
  return <Tag className={`bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-xl ${className}`}>{children}</Tag>;
}