# Kaique Selvino | Advogado

Este é o site profissional do advogado Kaique Selvino, desenvolvido com Next.js.

## Tecnologias
- Next.js
- React
- Tailwind CSS
- Lucide React (ícones)

## Scripts

```bash
npm install       # Instala as dependências
npm run dev       # Inicia o servidor de desenvolvimento
npm run build     # Compila o projeto
npm run start     # Inicia o servidor de produção
```

## Publicação
Hospede gratuitamente com [Vercel](https://vercel.com).
